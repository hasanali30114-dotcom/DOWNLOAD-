# No custom rules required for this framework-only app.
